﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;


namespace studiosoftware
{
    
    public partial class ViewEmployee : Form
    {
       
        SqlConnection conn = new SqlConnection("Data Source=LAPTOP-NONUB9GO\\SQLEXPRESS;Initial Catalog=Project;Integrated Security=True");
        public static string empid;
        
        public string emp
        {
            get { return empid; }
            set { empid = value; }
        }

        
        
        public ViewEmployee()
        {
            InitializeComponent();
            
         }

        private SqlConnection getConnection()
        {
            string connectionString;
            SqlConnection conn;
            connectionString = "Data Source=LAPTOP-NONUB9GO\\SQLEXPRESS;Initial Catalog=Project;Integrated Security=True";
            conn = new SqlConnection(connectionString);
            return conn;
        }
        private void bunifuFlatButton1_Click(object sender, EventArgs e)
        {
         this.Hide();
            Employee_Management emp = new Employee_Management();
            emp.display();
        }

        

        private void btnupdate_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Click on the row you want to update!","Click",MessageBoxButtons.OK,MessageBoxIcon.Information);
        }
        private void toolStripButton1_Click(object sender, EventArgs e)
        {

            this.Hide();
            Employee_Management emp = new Employee_Management();
            emp.Show();
        }
        private void btnDelete_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Click on the row you want to delete!", "Click", MessageBoxButtons.OK, MessageBoxIcon.Information);
        } 

       
        

        private void ViewEmployee_Load(object sender, EventArgs e)
        {
            /*Employee_Management emp = new Employee_Management();
            emp.display();*/
        }

        

        private void dataGridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            DialogResult dialogResult = MessageBox.Show("Are You Sure You Want to Delete?", "Confirm", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);

            if (dialogResult == DialogResult.Yes)
            {
                empid = Convert.ToString(dataGridView.Rows[e.RowIndex].Cells[0].Value);

                SqlCommand cmd = new SqlCommand("DELETE FROM dbo.Employee_info where Emp_id = " + empid + "", conn);

                cmd.Connection = getConnection();
                cmd.Connection.Open();
                cmd.ExecuteNonQuery();

                cmd.Connection.Close();
            }

            Employee_Management emp = new Employee_Management();
            emp.display();

        }

        private void dataGridView_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            
            
            this.Hide();
            UpdateEmployee update = new UpdateEmployee() ;
            update.Show();

            try
            {
                update.emp_id.Text = dataGridView.CurrentRow.Cells[0].Value.ToString();
                update.firstName.Text = dataGridView.CurrentRow.Cells[1].Value.ToString();
                update.lastName.Text = dataGridView.CurrentRow.Cells[2].Value.ToString();
                update.email.Text = dataGridView.CurrentRow.Cells[3].Value.ToString();
                update.address.Text = dataGridView.CurrentRow.Cells[4].Value.ToString();
                update.dobDatepicker.Value = Convert.ToDateTime(dataGridView.CurrentRow.Cells[5].Value.ToString());


               if (dataGridView.CurrentRow.Cells[6].Value.ToString() == " Female")
                {

                    update.Female.Checked = true;
                    update.Male.Checked = false;


                }
               else 

                {
                    update.Male.Checked = true;
                    update.Female.Checked = false;
                    

                }
                

                update.joinedDatepicker.Value = Convert.ToDateTime(dataGridView.CurrentRow.Cells[7].Value.ToString());
                update.mobileNumber.Text = dataGridView.CurrentRow.Cells[8].Value.ToString();

            }

            catch (Exception ex)
            {
                MessageBox.Show("Exception: " + ex.Message);
            }
            
        }
    }
}
