﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Text.RegularExpressions;

namespace studiosoftware
{
    
    public partial class UpdateEmployee : Form
    {
       

        SqlConnection conn = new SqlConnection("Data Source=LAPTOP-NONUB9GO\\SQLEXPRESS;Initial Catalog=Project;Integrated Security=True");
        SqlCommand cmd;

        public static string empid;

        public string emp
        {
            get { return empid; }
            set { empid = value; }
        }
        public UpdateEmployee()
        {
            InitializeComponent();
        }
        private SqlConnection getConnection()
        {
            string connectionString;
            SqlConnection conn;
            connectionString = "Data Source=LAPTOP-NONUB9GO\\SQLEXPRESS;Initial Catalog=Project;Integrated Security=True";
            conn = new SqlConnection(connectionString);
            return conn;
        }
        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            this.Hide();
            Employee_Management emp = new Employee_Management();
            emp.display();
        }

        private void updateButton_Click(object sender, EventArgs e)
        {

            string value = "";
            bool isChecked = Female.Checked;
            if (isChecked)
                value = "Female";
            else
                value = "Male";

           
            cmd = new SqlCommand("UPDATE Employee_info SET fName = '" + firstName.Text + "', lName ='" + lastName.Text + "', email = '" + email.Text + "' , DOB = '" + dobDatepicker.Value + "' , address = '" + address.Text + "', gender = '" + value + "', joinedDate = '" + joinedDatepicker.Value + "', mobileNum = '" + mobileNumber.Text + "' where Emp_Id = '" + emp_id.Text + "'", conn);
            cmd.Connection = getConnection();
            cmd.Connection.Open();
            cmd.ExecuteNonQuery();

            cmd.Connection.Close();

            MessageBox.Show("Record updated successfully!", "Updated", MessageBoxButtons.OK, MessageBoxIcon.Information);
            this.Hide();
           
            Employee_Management emp = new Employee_Management();
            emp.display();


        }        

        private void btnSearch_Click(object sender, EventArgs e)
        {
            
            /*conn.Open();
            SqlCommand cmd = conn.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select * from [Employee_info] where fname = '" + firstName.Text + "'";
            cmd.ExecuteNonQuery();
            conn.Close();
            firstName.Text = " ";
            lastName.Text = " ";
            email.Text = " ";
            dobDatepicker.Value = " ";
            address.Text = " ";
            gender;*/


        }

        private void firstName_Leave(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(firstName.Text) == true)
            {
                firstName.Focus();
                firstNameErrorProvider.SetError(this.firstName, "Required!");
            }

            else
            {
                firstNameErrorProvider.Clear();
            }
        }



        private void lastName_Leave(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(lastName.Text) == true)
            {
                lastName.Focus();
                lastNameErrorProvider.SetError(this.lastName, "Required!");
            }

            else
            {
                lastNameErrorProvider.Clear();
            }
        }

        private void email_Validating(object sender, CancelEventArgs e)
        {
            string pattern = "^([0-9a-zA-Z]([-\\.\\w]*[0-9a-zA-Z])*@([0-9a-zA-Z][-\\w]*[0-9a-zA-Z]\\.)+[a-zA-Z]{2,9})$";
            if (Regex.IsMatch(email.Text, pattern))
            {
                emailErrorProvider.Clear();
            }
            else
            {
                emailErrorProvider.SetError(this.email, "Invalid email!");
                return;
            }
        }

       
        private void mobileNumber_Leave(object sender, EventArgs e)
        {

            if (string.IsNullOrEmpty(mobileNumber.Text) == true)
            {
                mobileNumber.Focus();
                mobileNumErrorProvider.SetError(this.mobileNumber, "Required!");
            }

            else
            {
                mobileNumErrorProvider.Clear();
            }
        }

        private void address_Leave(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(address.Text) == true)
            {
                address.Focus();
                addressErrorProvider.SetError(this.address, "Required!");
            }

            else
            {
                addressErrorProvider.Clear();
            }
        }

        
        
    }
}
