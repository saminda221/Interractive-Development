﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace studiosoftware
{
    public partial class Delete : Form
    {
        SqlConnection conn = new SqlConnection("Data Source=LAPTOP-NONUB9GO\\SQLEXPRESS;Initial Catalog=Project;Integrated Security=True");
        public static string empid;

        public string emp
        {
            get { return empid; }
            set { empid = value; }
        }
        public Delete()
        {
            InitializeComponent();

        }

        private SqlConnection getConnection()
        {
            string connectionString;
            SqlConnection conn;
            connectionString = "Data Source=LAPTOP-NONUB9GO\\SQLEXPRESS;Initial Catalog=Project;Integrated Security=True";
            conn = new SqlConnection(connectionString);
            return conn;
        }
       
        private void dataGridView_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            empid = Convert.ToString(dataGridView.Rows[e.RowIndex].Cells[0].Value);

            SqlCommand cmd = new SqlCommand("DELETE FROM dbo.Employee_info where Emp_id = " + empid + "", conn);

            cmd.Connection = getConnection();
            cmd.Connection.Open();
            cmd.ExecuteNonQuery();

            cmd.Connection.Close();
            MessageBox.Show("Record deleted successfully!", "Deleted", MessageBoxButtons.OK, MessageBoxIcon.Information);
            display();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            Employee_Management emp = new Employee_Management();
            emp.display();
        }

        private void Delete_Load(object sender, EventArgs e)
        {
           
            display();
        }

        public void display()
        {
       

            try
            {
                //sql connection object
                using (SqlConnection conn = getConnection())
                {

                    //retrieve the SQL Server instance version
                    string query = @"SELECT *
                                  FROM Employee_info";


                    //define the SqlCommand object
                    SqlCommand cmd = new SqlCommand(query, conn);


                    //Set the SqlDataAdapter object
                    SqlDataAdapter dAdapter = new SqlDataAdapter(cmd);

                    //define dataset
                    DataSet ds = new DataSet();

                    //fill dataset with query results
                    dAdapter.Fill(ds);

                    //set DataGridView control to read-only
                    dataGridView.ReadOnly = true;

                    //set the DataGridView control's data source/data table
                    dataGridView.DataSource = ds.Tables[0];


                    //close connection
                    conn.Close();
                }
            }
            catch (Exception ex)
            {
                //display error message
                MessageBox.Show("Exception: " + ex.Message);
            }
        }
    }
}
